#ifndef ICERRARGUASSAPFING_H_INCLUDED
#define ICERRARGUASSAPFING_H_INCLUDED

class ICerrarGuassapFing {
public:
    virtual void cerrarSesion() = 0;
};

#endif // ICERRARGUASSAPFING_H_INCLUDED
