#include <string>

typedef std::string TelefonoUsuario;
typedef std::string NombreGrupo;
typedef int IdMensaje;
typedef int IdConversacion;
