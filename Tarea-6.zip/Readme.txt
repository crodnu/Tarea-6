Los datos se cargan ejecutando 
datos.txt > Tarea-6